@extends('layout')

@section('content')
    <div class="row">
        @foreach ($movieData as $movie)
            <div class="col-md-4">
                <div class="card">
                    <img src="{{ asset('images/' . $movie['foto_sampul']) }}" class="card-img-top" alt="{{ $movie['judul'] }}">
                    <div class="card-body">
                        <h5 class="card-title">{{ $movie['judul'] }}</h5>
                        <p class="card-text">{{ $movie['sinopsis'] }}</p>
                        <p class="card-text"><strong>Tahun:</strong> {{ $movie['tahun'] }}</p>
                        <p class="card-text"><strong>Pemain:</strong> {{ implode(', ', $movie['pemain']) }}</p>
                        <a href="{{ route('movie.detail', ['id' => $movie['id']]) }}" class="btn btn-primary">Selengkapnya</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
